package etourpack;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
@Controller
@RequestMapping("/Login")
public class LoginController
{
	@Autowired
	LoginDAO logindao;
	@RequestMapping(method = RequestMethod.POST)
	public String processSubmit(@Valid @ModelAttribute("mylogin") Login login,BindingResult result)
		{
		if(result.hasErrors())
		{
			return "Login";
		}
		else
		{
			boolean flag=logindao.checkLogin(login);
			if(flag==true)
			return "welcome";
			else
				return "fail";
		}
	}
	@RequestMapping(method = RequestMethod.GET)
	public ModelAndView before()
	{
		Login login=new Login();
		return new ModelAndView("Login","mylogin",login);
 		
	}
}









