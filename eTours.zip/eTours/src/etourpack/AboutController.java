package etourpack;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
@Controller
@RequestMapping("/About")
public class AboutController
{
	@RequestMapping(method = RequestMethod.GET)
	public ModelAndView before()
	{
 		Person person=new Person();
		return new ModelAndView("About.definition","About",person);
	}
	
}