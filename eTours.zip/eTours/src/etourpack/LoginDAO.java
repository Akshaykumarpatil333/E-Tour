package etourpack;

public interface LoginDAO 
{
	boolean checkLogin(Login ref);
}
