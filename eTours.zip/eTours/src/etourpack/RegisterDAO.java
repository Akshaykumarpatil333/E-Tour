package etourpack;

public interface RegisterDAO {
	void save(Register ref);
}
