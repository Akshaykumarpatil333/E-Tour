package etourpack;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
@Controller
@RequestMapping("/Register")
public class RegisterController
{
	@Autowired
	RegisterValidator registervalidator;
	@Autowired
	RegisterDAO registerdao;
	List <String>publisherlist;
	@RequestMapping(method = RequestMethod.POST)
	public String processSubmit(@Valid	@ModelAttribute("myregister")Register register,BindingResult result)
		{
		registervalidator.validate(register, result);
		System.out.println("processSubmit is called");
		System.out.println("in ProcessSubmit\t"+register);
		if(result.hasErrors())
		{
			return "Register.definition";
		}
		else
		{
			registerdao.save(register);
			return "success_person";
		}
	}
	/*if the following method is not there, after submitting, dob textfield
	shows string format of date entered,and then in case of any validation
	error, entered date (mm/dd/yy) format is suddenly changes to String,
	so u need to again enter the date.
	now with following method , this problem is not there.
	*/
	@InitBinder
    public void initBinder(WebDataBinder webDataBinder) {
		System.out.println("initBinder is called");
             SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");    
             webDataBinder.registerCustomEditor(Date.class,"dob", new CustomDateEditor(dateFormat, false));
         }
	
	@RequestMapping(method = RequestMethod.GET)
	public ModelAndView before()
	{
		Register register=new Register();
		return new ModelAndView("Register.definition","myregister",register);
	}
}














