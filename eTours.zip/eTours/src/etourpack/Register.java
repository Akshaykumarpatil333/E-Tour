package etourpack;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Register 
{
	private int c_id;
	private Date dob;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getId() {
		return c_id;
	}
	public void setId(int id) {
		this.c_id = id;
	}
	 
    @Column(name="name")
	@NotEmpty(message="name can not be empty")
	@Length(min=4,max=20,message="name must be between ${min} and ${max} characters")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "name must contain characters")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(name="address")
	@NotEmpty(message="address can not be empty")
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Column(name="username")
	@NotEmpty(message="user name can not be empty")
	@Length(min=4,max=20,message="user name must be between ${min} and ${max} characters")
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	@Column(name="password")
	@NotEmpty(message="Password cannot be blank")
	@Size(min=4,max=8,message="Password should be minimum of ${min} and maximum of ${max}")
	@Pattern(regexp = "^[A-Za-z]+[0-9]+$", message = "password must contain characters as well as digits")
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Column(name="email")
	@NotEmpty(message="email can not be empty")
	@Email(message="invalid email id")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Column(name="dob")
	@Temporal(javax.persistence.TemporalType.DATE)
	@NotNull(message="Date can't be empty")
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	
	private String name,address,username,password,confirmpassword,email,mobile;
	@Column(name="mobile")
	@NotEmpty(message="mobile no. compulsory")
	@Pattern(regexp = "^[0-9]{10}+$", message = "mobile must contain 10 digits")
	public String getMobile() {
		return mobile;
	}
	@Override
	public String toString() {
		return "Register [name=" + name + ", address=" + address
				+ ", username=" + username + ", password=" + password
				+ ", email=" + email + ", mobile=" + mobile + ", dob=" + dob
				+ "]";
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	@Transient
	public String getConfirmpassword() {
		return confirmpassword;
	}
	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}
	
	
}
